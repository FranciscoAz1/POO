/**
 * The Projecy module definition.
 */
module Projecy {
}