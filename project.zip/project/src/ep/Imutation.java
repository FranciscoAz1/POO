
package ep;

import dss.IEvent;

/**
 * The Imutation interface provides a contract for mutation events in a simulation.
 */
public interface Imutation extends IEvent {
}
