package ep;

import dss.IEvent;

/**
 * The Ideath interface provides a contract for death events in a simulation.
 */
public interface Ideath extends IEvent {
    
    public Individual getIndividual();

    public String toString();
}
